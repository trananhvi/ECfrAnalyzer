package com.vitran.ecfranalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECfrAnalyzerApplicationTests {

    @Test
    void contextLoads() {
    }

}
